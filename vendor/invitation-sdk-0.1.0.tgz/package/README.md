# invitation-sdk

SDK trang thiệp Invitation cho web chạy trên domain của brand: đọc trang, form theo Trường thông tin, tải ảnh khách, tạo thiệp,
nhận kết quả (video hoặc ảnh), đăng ký và xác nhận mã email. ESM + TypeScript, không phụ thuộc framework.

```ts
import { createInvitation } from 'invitation-sdk'
const inv = createInvitation()
const site = await inv.readSite()
const { id } = await inv.createCard({ template: site.templates[0].id, guest: { full_name: 'Nguyễn An' } })
const card = await inv.waitCard(id)   // { url, kind: 'video' | 'image', downloadUrl }
```

Nhận thiệp ngay khi xong (realtime): `createInvitation({ realtime: { createClient } })` với `createClient` của `@supabase/supabase-js`.

Hướng dẫn đầy đủ: [DEV_GUIDE.md](../docs/DEV_GUIDE.md).
